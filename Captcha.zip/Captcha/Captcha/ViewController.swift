//
//  ViewController.swift
//  Captcha
//
//  Created by Arpit Mendpara on 10/03/19.
//  Copyright © 2019 Arpit Mendpara. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var alphas : [String] = []
    var captchaString = ""
    var i1 : Int = 0
    var i2 : Int = 0
    var i3 : Int = 0
    var i4 : Int = 0
    var i5 : Int = 0
    @IBOutlet weak var CaptchaLabel: UILabel!
    @IBOutlet weak var CaptchaTextField: UITextField!
    @IBOutlet weak var StatusLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        alphas = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
    }
    
    override func viewWillAppear(_ animated: Bool) {
        reloadCaptcha()
    }
    
    func reloadCaptcha(){
        i1 = Int(arc4random()) % alphas.count
        i2 = Int(arc4random()) % alphas.count
        i3 = Int(arc4random()) % alphas.count
        i4 = Int(arc4random()) % alphas.count
        i5 = Int(arc4random()) % alphas.count
        
        captchaString = "\(alphas[i1])\(alphas[i2])\(alphas[i3])\(alphas[i4])\(alphas[i5])"
        print(captchaString)
        CaptchaLabel.text = captchaString
    }
    @IBAction func ReloadButton(_ sender: UIButton) {
        reloadCaptcha()
    }
    
    @IBAction func SubmitButton(_ sender: UIButton) {
        if CaptchaLabel.text == CaptchaTextField.text{
            StatusLabel.text = "Success"
            StatusLabel.textColor = .green
        } else{
            StatusLabel.text = "Faild"
            StatusLabel.textColor = .red
        }
    }
    
}

